import io
import numpy as np, pandas as pd
from flask import Flask, render_template, request, jsonify, Response
import ml_core as core

app = Flask(__name__)
print("Training models and running analysis labs (about 20-40 seconds)...")
S = core.build()
print("Ready -> open http://127.0.0.1:5000")
COLS_A, COLS_B = core.FEATURES["A"][1], core.FEATURES["B"][1]
REQ = ["age_m", "sex", "height_cm", "weight_kg", "muac_mm"]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/init")
def init():
    r = S["results"]
    table = [{k: (None if (isinstance(v, float) and np.isnan(v)) else v) for k, v in row.items()}
             for row in r.to_dict("records")]
    bestA = r[r.Set == "A"].sort_values("Kappa").iloc[-1]
    bestB = r[r.Set == "B"].sort_values("Kappa").iloc[-1]
    return jsonify(table=table, prev=S["prev"], n=len(S["df"]), rob=S["rob"], shift=S["shift"],
                   roc=S["triage"]["roc"], rule=S["triage"]["rule"],
                   kpi=dict(kA=round(bestA.Kappa, 3), kB=round(bestB.Kappa, 3),
                            sB=round(bestB.Sensitivity, 3), mA=bestA.Model, mB=bestB.Model))


@app.route("/api/triage")
def triage():
    t = float(request.args.get("t", 0.3)); sc, y = S["triage"]["score"], S["triage"]["y"]
    f = sc >= t; n = len(y)
    return jsonify(sens=round(float((f & y).sum() / y.sum()), 3),
                   spec=round(float((~f & ~y).sum() / (~y).sum()), 3),
                   flagged=round(float(f.mean() * 100), 1),
                   missed=round(float((y & ~f).sum() / n * 1000), 1),
                   true_cases=round(float(y.mean() * 1000), 1),
                   false_alarm=round(float((f & ~y).sum() / n * 1000), 1))


def explain(row):
    X = pd.DataFrame([row])[COLS_B]; m = S["best"]["B"][1]
    p = m.predict_proba(X)[0]; base = float(p[2] + p[3]); out = []
    for c in COLS_B:
        X2 = X.copy(); X2[c] = S["median"][c]
        q = m.predict_proba(X2)[0]
        out.append(dict(feature=c, effect=round(base - float(q[2] + q[3]), 3)))
    return base, out


@app.route("/api/predict", methods=["POST"])
def predict():
    d = request.get_json()
    try:
        age, sex = float(d["age"]), int(d["sex"])
        h, w, m = float(d["height"]), float(d["weight"]), float(d["muac"])
        assert 6 <= age <= 59 and 40 <= h <= 130 and 3 <= w <= 30 and 80 <= m <= 220
    except Exception:
        return jsonify(error="Check values: age 6-59 months, height 40-130 cm, weight 3-30 kg, MUAC 80-220 mm."), 400
    haz, whz, waz = core.who_zscores(age, sex, h, w)
    who = int(core.label(np.array([haz]), np.array([whz]))[0])
    row = dict(age_m=age, sex=sex, height_cm=h, weight_kg=w, muac_mm=m)
    ml = {}
    for k, (name, cols) in core.FEATURES.items():
        mn, mod = S["best"][k]; X = pd.DataFrame([row])[cols]
        pred = int(mod.predict(X)[0]); pb = mod.predict_proba(X)[0]
        ml[k] = dict(features=name, model=mn, prediction=core.CLASSES[pred],
                     confidence=round(float(pb.max()) * 100, 1), agrees=pred == who)
    risk, ex = explain(row)
    return jsonify(haz=round(float(haz), 2), whz=round(float(whz), 2), waz=round(float(waz), 2),
                   who=core.CLASSES[who], ml=ml, muac_rule="At risk (MUAC < 125 mm)" if m < 125 else "Not flagged",
                   risk=round(risk * 100, 1), explain=ex)


@app.route("/api/batch", methods=["POST"])
def batch():
    try:
        df = pd.read_csv(request.files["file"])
        df.columns = [c.strip().lower() for c in df.columns]
        miss = [c for c in REQ if c not in df.columns]
        if miss:
            return jsonify(error="Missing columns: " + ", ".join(miss)), 400
        df = df[REQ].apply(pd.to_numeric, errors="coerce").dropna().head(50000).reset_index(drop=True)
        assert len(df) > 0
    except Exception:
        return jsonify(error="Could not read CSV. Use columns: " + ", ".join(REQ)), 400
    haz, whz, waz = core.who_zscores(df.age_m, df.sex, df.height_cm, df.weight_kg)
    df["HAZ"], df["WHZ"], df["WAZ"] = np.round(haz, 2), np.round(whz, 2), np.round(waz, 2)
    bad = (abs(haz) > 6) | (whz < -5) | (whz > 5) | (waz < -6) | (waz > 5)   # WHO flexible-exclusion limits
    df["data_quality"] = np.where(bad, "Implausible - check", "OK")
    df["WHO_class"] = [core.CLASSES[i] for i in core.label(haz, whz)]
    df["ML_A"] = [core.CLASSES[i] for i in S["best"]["A"][1].predict(df[COLS_A])]
    df["ML_B"] = [core.CLASSES[i] for i in S["best"]["B"][1].predict(df[COLS_B])]
    ok = df[~bad]
    summ = {c: dict(who=int((ok.WHO_class == c).sum()), mlA=int((ok.ML_A == c).sum()), mlB=int((ok.ML_B == c).sum()))
            for c in core.CLASSES}
    csv = df.to_csv(index=False)
    return jsonify(n=len(df), flagged=int(bad.sum()), summary=summ,
                   agreeA=round(float((ok.WHO_class == ok.ML_A).mean() * 100), 1) if len(ok) else 0,
                   agreeB=round(float((ok.WHO_class == ok.ML_B).mean() * 100), 1) if len(ok) else 0,
                   rows=df.head(15).to_dict("records"), csv=csv)


@app.route("/sample.csv")
def sample():
    d = core.make_data(300, seed=9)[REQ]
    d.loc[3, "height_cm"] = 40.0   # deliberate data-entry error to show the quality flag
    return Response(d.to_csv(index=False), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=sample_survey.csv"})


if __name__ == "__main__":
    app.run(debug=False, port=5000)
