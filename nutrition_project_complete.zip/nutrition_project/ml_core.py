"""Core engine: synthetic survey data, WHO-style labels, ML models and the 4 analysis labs."""
import numpy as np, pandas as pd
from sklearn.base import clone
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, f1_score, cohen_kappa_score, roc_curve, roc_auc_score

CLASSES = ["Normal", "Stunted", "Wasted", "Stunted+Wasted"]
AGE = [6, 12, 24, 36, 48, 60]
H50 = [67.6, 75.7, 87.8, 96.1, 103.3, 110.0]
W50 = [7.9, 9.6, 12.2, 14.3, 16.3, 18.3]
HT = [65, 75, 85, 95, 105, 110]
WH50 = [7.0, 9.0, 11.5, 14.0, 16.8, 18.5]
FEATURES = {
    "A": ("Full (age, sex, height, weight, MUAC)", ["age_m", "sex", "height_cm", "weight_kg", "muac_mm"]),
    "B": ("Field screening (age, sex, weight, MUAC)", ["age_m", "sex", "weight_kg", "muac_mm"]),
    "C": ("Minimal (age, sex, MUAC)", ["age_m", "sex", "muac_mm"]),
}
NUM = ["Accuracy", "MacroF1", "Kappa", "Sensitivity", "Specificity"]


def who_zscores(age, sex, height, weight):
    """APPROXIMATE WHO z-scores (sex: 1 boy, 0 girl). Swap for official WHO LMS tables."""
    h50 = np.interp(age, AGE, H50) - 0.9 * (np.asarray(sex) == 0)
    haz = (height - h50) / (0.047 * h50)
    whz = (weight - np.interp(height, HT, WH50)) / (0.105 * np.interp(height, HT, WH50))
    w50 = np.interp(age, AGE, W50)
    return haz, whz, (weight - w50) / (0.12 * w50)


def label(haz, whz):
    return np.select([(haz < -2) & (whz < -2), whz < -2, haz < -2], [3, 2, 1], 0)


def make_data(n=12000, seed=42, zh_mu=-1.3, zw_mu=-0.9):
    rng = np.random.default_rng(seed)
    age = rng.integers(6, 60, n); sex = rng.integers(0, 2, n)
    z_h = rng.normal(zh_mu, 1.25, n)
    z_w = 0.35 * z_h + np.sqrt(1 - .35 ** 2) * rng.normal(zw_mu, 1.1, n)
    h50 = np.interp(age, AGE, H50) - 0.9 * (sex == 0)
    height = h50 + z_h * 0.047 * h50 + rng.normal(0, .4, n)
    weight = np.interp(height, HT, WH50) * (1 + 0.105 * z_w) + rng.normal(0, .15, n)
    muac = 138 + 6.2 * z_w + 0.12 * (age - 30) + rng.normal(0, 5, n)
    df = pd.DataFrame(dict(age_m=age, sex=sex, height_cm=height.round(1),
                           weight_kg=weight.round(2), muac_mm=muac.round(0)))
    df["haz"], df["whz"], df["waz"] = who_zscores(df.age_m, df.sex, df.height_cm, df.weight_kg)
    df["status"] = label(df.haz, df.whz)
    return df


def add_noise(df, L, seed=7):
    """Measurement error level L: age misreporting, height/weight/MUAC reading error."""
    r = np.random.default_rng(seed); d = df.copy(); n = len(d)
    d["age_m"] = np.clip(d.age_m + r.normal(0, .8 * L, n), 6, 59)
    d["height_cm"] = d.height_cm + r.normal(0, .6 * L, n)
    d["weight_kg"] = (d.weight_kg + r.normal(0, .1 * L, n)).clip(2, None)
    d["muac_mm"] = d.muac_mm + r.normal(0, 1.5 * L, n)
    return d


def build():
    df = make_data()
    tr, te = train_test_split(df, test_size=0.3, stratify=df.status, random_state=1)
    zoo = {
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)),
        "Random Forest": RandomForestClassifier(150, random_state=1, n_jobs=-1, class_weight="balanced"),
        "Gradient Boosting": GradientBoostingClassifier(random_state=1),
    }
    rows, fitted = [], {}
    for k, (name, cols) in FEATURES.items():
        for mn, m in zoo.items():
            m = clone(m).fit(tr[cols], tr.status); p = m.predict(te[cols])
            sev, ps = te.status >= 2, p >= 2
            rows.append(dict(Set=k, Features=name, Model=mn,
                             Accuracy=accuracy_score(te.status, p),
                             MacroF1=f1_score(te.status, p, average="macro"),
                             Kappa=cohen_kappa_score(te.status, p),
                             Sensitivity=float((ps & sev).sum() / sev.sum()),
                             Specificity=float((~ps & ~sev).sum() / (~sev).sum())))
            fitted[(k, mn)] = m
    res = pd.DataFrame(rows)
    best = {k: (r.Model, fitted[(k, r.Model)]) for k in FEATURES
            for r in [res[res.Set == k].sort_values("Kappa").iloc[-1]]}
    sev = te.status >= 2
    rule = te.muac_mm < 125
    rule_row = dict(Set="-", Features="MUAC < 125 mm rule", Model="Cut-off rule",
                    Sensitivity=float((rule & sev).sum() / sev.sum()),
                    Specificity=float((~rule & ~sev).sum() / (~sev).sum()))
    results = pd.concat([res, pd.DataFrame([rule_row])], ignore_index=True)

    # ---- Lab 1: triage (screening model B) ----
    mB = best["B"][1]; colsB = FEATURES["B"][1]
    pr = mB.predict_proba(te[colsB]); score = pr[:, 2] + pr[:, 3]; y = sev.values
    fpr, tpr, _ = roc_curve(y, score); idx = np.linspace(0, len(fpr) - 1, 80).astype(int)
    triage = dict(score=score, y=y, roc=dict(fpr=fpr[idx].round(4).tolist(), tpr=tpr[idx].round(4).tolist(),
                  auc=round(float(roc_auc_score(y, score)), 3)),
                  rule=dict(sens=rule_row["Sensitivity"], fpr=1 - rule_row["Specificity"]))

    # ---- Lab 2: robustness to measurement error ----
    mA = best["A"][1]; colsA = FEATURES["A"][1]
    aug = pd.concat([tr] + [add_noise(tr, L, 100 + L) for L in (2, 4)])
    mA_noisy = RandomForestClassifier(150, random_state=2, n_jobs=-1, class_weight="balanced")
    mA_noisy.fit(aug[colsA], np.concatenate([tr.status.values] * 3))
    rob = dict(levels=[], who=[], ml_clean=[], ml_noisy=[], who_k=[], ml_clean_k=[], ml_noisy_k=[])
    for L in range(6):
        nz = add_noise(te, L)
        hz, wz, _ = who_zscores(nz.age_m, nz.sex, nz.height_cm, nz.weight_kg)
        preds = [label(hz, wz), mA.predict(nz[colsA]), mA_noisy.predict(nz[colsA])]
        rob["levels"].append(L)
        for key, p in zip(["who", "ml_clean", "ml_noisy"], preds):
            rob[key].append(round(float(accuracy_score(te.status, p)), 3))
            rob[key + "_k"].append(round(float(cohen_kappa_score(te.status, p)), 3))

    # ---- Lab 3: population shift (prevalence estimation) ----
    shift = []
    for i, (zh, zw) in enumerate([(-.6, -.3), (-.9, -.5), (-1.3, -.9), (-1.6, -1.2), (-1.9, -1.5), (-2.2, -1.8)]):
        d = make_data(4000, 500 + i, zh, zw)
        shift.append(dict(
            who=round(float((d.status >= 2).mean() * 100), 1),
            A=round(float((best["A"][1].predict(d[colsA]) >= 2).mean() * 100), 1),
            B=round(float((mB.predict(d[colsB]) >= 2).mean() * 100), 1),
            stunt_who=round(float(d.status.isin([1, 3]).mean() * 100), 1)))
    prev = (df.status.map(dict(enumerate(CLASSES))).value_counts(normalize=True) * 100).round(1).to_dict()
    return dict(df=df, te=te, tr=tr, results=results, best=best, triage=triage, rob=rob, shift=shift,
                prev=prev, median=tr[FEATURES["A"][1]].median().to_dict())
